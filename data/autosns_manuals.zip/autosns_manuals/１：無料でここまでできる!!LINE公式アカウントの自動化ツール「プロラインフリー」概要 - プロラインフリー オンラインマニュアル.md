# １：無料でここまでできる!!LINE公式アカウントの自動化ツール「プロラインフリー」概要 - プロラインフリー オンラインマニュアル

Source: https://autosns.co.jp/manual/start/one-proline-overview

[はじめ方](https://autosns.co.jp/manual/category/start)

# １：無料でここまでできる!!LINE公式アカウントの自動化ツール「プロラインフリー」概要

2021年7月15日

![１：無料でここまでできる!!LINE公式アカウントの自動化ツール「プロラインフリー」概要](https://autosns.co.jp/manual/wp-content/uploads/2021/05/eye_one-proline-overview.png)

[このページを印刷](javascript:void(0))

プロラインフリーのことが２分半で分かる動画です。

あなたがやりたい「あんなこと」から「こんなこと」まで、  
プロラインフリーならワンストップで全て実現できます。

以下の動画をご確認ください。

関連記事

**プロラインフリーを理解する３つの動画**  
～公式LINEや他ツールとの違いを徹底比較!!～
   
   
※この記事は、下記のシリーズの「●１：」にあたります。

●１：無料でここまでできる!!LINE公式アカウントの自動化ツール「プロラインフリー」概要←この記事

●２：プロラインフリー【超ステップ配信】はLINE公式アカウントとどう違うの？  
→[記事はコチラ](https://autosns.co.jp/manual/start/two-official-differ "●２：プロラインフリー【超ステップ配信】はLINE公式アカウントとどう違うの？ステップ数の数え方も")

●３：プロラインフリーと他ツールとの違いを徹底比較!!迷っている方必見！  
→[記事はコチラ](https://autosns.co.jp/manual/start/three-othertool-differ "●３：プロラインフリーと他ツールとの違いを徹底比較!!迷っている方必見！")

※**PC版LINEの場合、動作に様々な制限がある事がございます。**  
その為、正確な動作確認をしたい場合は、スマホ版LINEアプリをご利用ください。

[このページを印刷](javascript:void(0))

[はじめ方](https://autosns.co.jp/manual/category/start)の関連記事

* [![用語と概要](data:image/gif;base64,R0lGODdhAQABAPAAAN3d3QAAACwAAAAAAQABAAACAkQBADs=) 

  用語と概要

  2020年7月16日](https://autosns.co.jp/manual/start/term-overview "用語と概要")
* [![プラン・料金について](data:image/gif;base64,R0lGODdhAQABAPAAAN3d3QAAACwAAAAAAQABAAACAkQBADs=) 

  プラン・料金について

  2020年7月16日](https://autosns.co.jp/manual/start/fee-structure "プラン・料金について")
* [![プロラインフリーのアカウントの作成方法](data:image/gif;base64,R0lGODdhAQABAPAAAN3d3QAAACwAAAAAAQABAAACAkQBADs=) 

  プロラインフリーのアカウントの作成方法

  2020年7月16日](https://autosns.co.jp/manual/start/connect/create-proline-account "プロラインフリーのアカウントの作成方法")
* [![LINE公式アカウントの作成方法](data:image/gif;base64,R0lGODdhAQABAPAAAN3d3QAAACwAAAAAAQABAAACAkQBADs=) 

  LINE公式アカウントの作成方法

  2020年7月16日](https://autosns.co.jp/manual/start/connect/create-line "LINE公式アカウントの作成方法")
* [![プロラインフリーとLINE公式アカウントとの連携方法](data:image/gif;base64,R0lGODdhAQABAPAAAN3d3QAAACwAAAAAAQABAAACAkQBADs=) 

  プロラインフリーとLINE公式アカウントとの連携方法

  2020年7月16日](https://autosns.co.jp/manual/start/connect/autosns-line "プロラインフリーとLINE公式アカウントとの連携方法")
* [![プロラインフリーに最初の１⼈⽬を友だち追加する](data:image/gif;base64,R0lGODdhAQABAPAAAN3d3QAAACwAAAAAAQABAAACAkQBADs=) 

  プロラインフリーに最初の１⼈⽬を友だち追加する

  2020年7月16日](https://autosns.co.jp/manual/start/connect/add-first-friend "プロラインフリーに最初の１⼈⽬を友だち追加する")